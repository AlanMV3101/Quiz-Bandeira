package com.example.teste1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class RANKING extends AppCompatActivity {

    private TextView textView4, textView7;
    private Button telaprin, telat1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ranking);
        setTitle("RANKING");


        textView4 = findViewById(R.id.textView4);
        String nomeUsuario = getIntent().getStringExtra("nomeUsuario");
        Log.d("MainActivity", "Nome do usuário: " + nomeUsuario);
        textView4.setText(nomeUsuario);

        textView7 = findViewById(R.id.textView7);
        int resultado = getIntent().getIntExtra("pontuacao", 0);
        textView7.setText(String.valueOf(resultado));

        telaprin = findViewById(R.id.telaprin);
        telat1 = findViewById(R.id.telat1);

        telaprin.setOnClickListener(view -> {
            Intent intent = new Intent(RANKING.this, MainActivity.class);
            startActivity(intent);
        });

        telat1.setOnClickListener(view -> {
            Intent intent = new Intent(RANKING.this, Bandeira1.class);
            startActivity(intent);
        });

    }

}