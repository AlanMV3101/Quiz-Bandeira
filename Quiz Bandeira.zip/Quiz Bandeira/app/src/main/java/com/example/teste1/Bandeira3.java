package com.example.teste1;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Bandeira3 extends AppCompatActivity {

    private Button bntREP1;

    private int pontuacaoband3 = 0;

    private RadioButton RBT1, RBT2, RBT3, RBT4;
    private RadioGroup radio_group;

    private TextView textViewPontuacao;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bandeira3);
        setTitle("Que país é esse ?");

        bntREP1 = findViewById(R.id.bntREP1);
        RBT1 = findViewById(R.id.RBT1);
        RBT2 = findViewById(R.id.RBT2);
        RBT3 = findViewById(R.id.RBT3);
        RBT4 = findViewById(R.id.RBT4);

        bntREP1.setEnabled(false);



        RBT1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateNextButtonState();
            }
        });

        RBT2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateNextButtonState();
            }
        });

        RBT3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateNextButtonState();
            }
        });

        RBT4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateNextButtonState();
            }
        });


        radio_group = findViewById(R.id.radio_group);
        radio_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radioButtonSelecionado = group.findViewById(checkedId);
                if (radioButtonSelecionado != null) {
                    verificarResposta(radioButtonSelecionado.getText().toString());
                }
            }
        });



        bntREP1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nomeUsuario = getIntent().getStringExtra("nomeUsuario");
                int resultado = getIntent().getIntExtra("pontuacao", 0) + pontuacaoband3;
                Intent intent = new Intent(Bandeira3.this, Bandeira4.class);
                intent.putExtra("nomeUsuario", nomeUsuario);
                intent.putExtra("pontuacao", resultado);
                Log.d("MainActivity", "Pontuação: " + resultado);
                startActivity(intent);
            }
        });



    }

    private void updateNextButtonState() {
        // Verifica se pelo menos um dos radio buttons está selecionado
        if (RBT1.isChecked() || RBT2.isChecked() || RBT3.isChecked() || RBT4.isChecked()) {
            bntREP1.setEnabled(true); // Habilita o botão
        } else {
            bntREP1.setEnabled(false); // Desabilita o botão
        }
    }

    private void verificarResposta(String respostaSelecionada) {
        String respostaCorreta = "CROACIA"; // Supondo que a resposta correta seja a opção B
        if (respostaSelecionada.equals(respostaCorreta)) {
            pontuacaoband3 = 10; // Adiciona 10 pontos para o usuário
            //textViewPontuacao = findViewById(R.id.text_view_pontuacao);
            //textViewPontuacao.setText("Pontuação: " + pontuacaoband3);
        }
    }
}