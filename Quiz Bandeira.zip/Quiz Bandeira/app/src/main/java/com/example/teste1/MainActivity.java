package com.example.teste1;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {

    private Button btnTela1;
    private EditText meuEditText;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("Início");

        btnTela1 = findViewById(R.id.btnTela1);
        meuEditText = findViewById(R.id.meuEditText);
        btnTela1.setEnabled(false);

        meuEditText.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Nada a fazer aqui
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Verifica se o campo de entrada não está vazio
                if (s.length() > 0) {
                    btnTela1.setEnabled(true); // Habilita o botão
                } else {
                    btnTela1.setEnabled(false); // Desabilita o botão
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Nada a fazer aqui
            }
        });

        btnTela1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String nomeUsuario = meuEditText.getText().toString();
                Intent intent = new Intent(MainActivity.this, Bandeira1.class);
                intent.putExtra("nomeUsuario", nomeUsuario);
                startActivity(intent);

                Log.d("MainActivity", "Nome do usuário: " + nomeUsuario);

            }

        });
    }
}
